//parallax
var image = document.getElementsByClassName('parallax');
new simpleParallax(image, {
    overflow: true,
    transition: 'cubic-bezier(0,0,0,1)',
    delay: 1.5,
    scale: 3
});

//main-menu active link
$(function () {
    $('.nav-menu a').each(function () {
        var location = window.location.href;
        var link = this.href;
        if(location == link) {
            $(this).addClass('active');
        }
    });
});

//button go to top
$(function() {
    $(window).scroll(function() {
        if($(this).scrollTop() != 0) {
            $('#toTop').fadeIn();
        } else {
            $('#toTop').fadeOut();
        }
    });

    $('#toTop').click(function() {
            $('body,html').animate({scrollTop:0},800);
    });
});

//anchor links
$(document).ready(function(){
    $("#menu").on("click","a", function (event) {
        event.preventDefault();
        var id  = $(this).attr('href'),
        top = $(id).offset().top;
        $('body,html').animate({scrollTop: top}, 1500);
    });
});

//mobile menu
new Vue ({
  el: '#mobileMenu',
  data: {
    show: false,
  },
});

// owl-corousel Слайдер лектаров
$(".lecturers.owl-carousel").owlCarousel({
  loop: true,
  nav: true,
  items: 6,
  margin: 0,
  autoplay: false,
  responsive: {
    0:{
      items:1
    },
    420:{
      items:1
    },
    768:{
      items:2
    },
    1024: {
      items:3
    },
    1224:{
      items:3
    },
    1380:{
      items:4
    }
  },
});

// owl-corousel Слайдер курсов
$(".course-modules.owl-carousel").owlCarousel({
  loop: true,
  nav: true,
  items: 6,
  margin: 35,
  autoplay: false,
  videoHeight: 508,
  responsive: {
    0:{
      items:1
    },
    420:{
      items:1
    },
    768:{
      items:1
    },
    1024: {
      items:2
    },
    1224:{
      items:3
    },
    1380:{
      items:3
    }
  },
});


